



<script src="script/myscript.js"></script>












<div class="footer">

<div class="boxes"><a id="test" href="../error_report.php">ERROR REPORT</a></div>

<div class="boxes"><a id="test" href="../about.php">ABOUT US</a></div>

<div class="boxes"><a id="test" href="../privacy_policy.php">PRIVACY POLICY</a></div>

<div class="boxes"><a id="test" href="../term_of_use.php">TERMS OF USE</a></div>

<div class="boxes" id="boxes_social_media">
FOLLOW US

<div class="socialmedia"><a style="color:blue;" href="https://twitter.com/mycrazycoding" target="_blank"><i  class="fab fa-twitter-square" ></i></a></div>
<div class="socialmedia"><a style="color:#ff00ff;" href="https://www.instagram.com/mycrazycoding2020/" target="_blank"><i class="fab fa-instagram-square"></i></a></div>
<div class="socialmedia"><a style="color: #FF0000;" href="https://youtube.com/channel/UCOAmhGOjwvnSCKT74aZAhYQ" target="_blank"><i class="fab fa-youtube-square"></i></a></div>



</div>


</div>





<div class="ads">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7569865976437849"
     crossorigin="anonymous"></script>
<!-- right_side_ad -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:500px"
     data-ad-client="ca-pub-7569865976437849"
     data-ad-slot="2673909034"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script> 
  
</div>