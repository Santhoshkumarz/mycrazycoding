import java.io.*;
import java.util.*;
public class Example
{
      public static void main(String[] args) 
      {
           try
           {
                 File object = new File("file_name.txt");
                 Scanner file_reader = new Scanner(object);
                 while(file_reader.hasNextLine())
                 {
                      String s = file_reader.nextLine();
                       System.out.print(s);
                 }
                 file_reader.close();
           }               
           catch (Exception e) 
           {
                 return;
           }
      } 
}