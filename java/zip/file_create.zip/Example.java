import java.io.*;
public class Example
{
       public static void main(String[] args)
       {
               try 
               {
                      File file = new File("file_name.txt");
                      if (file.createNewFile()) 
                      {
                             System.out.println("File created.." );
                      } 
                      else 
                      {
                             System.out.println("File already exists.");
                      }
               } 
               catch (Exception e) 
               {
                      return;
               }
       } 
}