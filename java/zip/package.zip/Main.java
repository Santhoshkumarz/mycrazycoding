import Folder_name.class_name;
public class Main
{
	public static void main(String[] args) 
	{
		    class_name obj = new class_name();
            obj.display();
	}
}