package Folder_name;
public class class_name
{
      public void display()
      {
            System.out.print("mycrazycoding.com");
      }
}