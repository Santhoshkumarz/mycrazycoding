import java.io.*;
import java.util.*;
public class Example
{
     public static void main(String[] args) throws Exception
     {
           try
           {
                       BufferedWriter write_file=new BufferedWriter(new FileWriter("file.txt"));
                                         
                       write_file.write("C \n");
                       write_file.write("C++\n");
                       write_file.write("Java\n");
                       write_file.write("Python\n");
                       write_file.close();
           }

           catch(Exception e)
           {
                   return;
           }
     } 
}
