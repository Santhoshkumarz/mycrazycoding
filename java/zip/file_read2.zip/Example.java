import java.io.*;
import java.util.*;
public class Example
{
       public static void main(String[] args) throws Exception
       {
            try
            { 
                   BufferedReader read_file = new BufferedReader(new FileReader("file_name.txt"));
                             
                   String s;
                   while((s=read_file.readLine())!= null)
                   {
                        System.out.print(s);
                   }
                   read_file.close();
            }
            catch(Exception e)
            {
                   return;
            }
       } 
}