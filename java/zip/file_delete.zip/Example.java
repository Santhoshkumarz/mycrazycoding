import java.io.*;
public class Example
{
       public static void main(String[] args)
       {
             try 
             {
                   File file = new File("file_name.txt");
                   if (file.delete()) 
                   {
                        System.out.println("Deleted..");
                   } 
                   else 
                   {
                        System.out.println("Failed...");
                   }
             } 
             catch (Exception e) 
             {
                   return;
             }
       } 
}